# 📚 博学书城 - 现代化在线图书商城系统

[![Go Version](https://img.shields.io/badge/Go-1.21+-blue.svg)](https://golang.org/)
[![Gin Framework](https://img.shields.io/badge/Gin-1.9+-green.svg)](https://gin-gonic.com/)
[![MySQL](https://img.shields.io/badge/MySQL-5.7+-orange.svg)](https://www.mysql.com/)

## 🎯 项目概述

博学书城是一个基于Go语言开发的现代化在线图书商城系统，采用前后端分离架构，提供完整的图书浏览、搜索、购物车、收藏、订单管理等核心功能。系统设计注重用户体验，支持响应式布局，适配多种设备访问。

### 🌟 核心特性

- **📖 图书管理**: 支持图书分类、搜索、详情展示
- **🛒 购物车系统**: 本地存储，支持数量调整和持久化
- **💳 订单管理**: 完整的下单、支付、订单历史流程
- **👤 用户系统**: 注册、登录、个人资料管理
- **❤️ 收藏功能**: 用户可收藏喜欢的图书
- **🎨 轮播展示**: 动态轮播图展示推荐内容
- **📱 响应式设计**: 完美适配桌面端和移动端

## 🏗️ 技术架构

### 后端技术栈

| 技术        | 版本      | 用途     |
|-----------|---------|--------|
| **Go**    | 1.21+   | 主要开发语言 |
| **Gin**   | 1.9+    | Web框架  |
| **GORM**  | 1.25+   | ORM框架  |
| **MySQL** | 5.7+    | 主数据库   |
| **Redis** | 7.2.0+  | 缓存数据库  |
| **Nginx** | 1.21.0+ | 代理服务器  |
| **JWT**   | -       | 用户认证   |

## 📋 功能模块

### 1. 用户管理模块
- 用户注册与登录
- JWT Token认证
- 个人资料管理
- 密码修改

### 2. 图书管理模块
- 图书列表展示
- 分类筛选
- 搜索功能（模糊匹配）
- 图书详情页
- 热销图书推荐
- 新书上架展示

### 3. 购物车模块
- 添加/删除商品
- 数量调整
- 本地存储持久化
- 价格计算

### 4. 订单管理模块
- 订单创建
- 订单支付
- 订单历史查询
- 订单状态管理

### 5. 收藏功能模块
- 收藏/取消收藏
- 收藏列表展示
- 收藏数量统计

## 🔗 API文档

详细的API接口文档请参考：[API文档](./docs/api.md)

关于管理员页面的详细介绍: [管理员后台介绍 && API文档](./docs/admin-web.md)

### 主要接口概览

| 模块 | 接口 | 方法 | 描述 |
|------|------|------|------|
| 用户 | `/api/v1/user/register` | POST | 用户注册 |
| 用户 | `/api/v1/user/login` | POST | 用户登录 |
| 用户 | `/api/v1/user/profile` | GET | 获取用户信息 |
| 图书 | `/api/v1/book/list` | GET | 获取图书列表 |
| 图书 | `/api/v1/book/search` | GET | 搜索图书 |
| 图书 | `/api/v1/book/detail/:id` | GET | 获取图书详情 |
| 订单 | `/api/v1/order/create` | POST | 创建订单 |
| 订单 | `/api/v1/order/list` | GET | 获取订单列表 |
| 收藏 | `/api/v1/favorite/add` | POST | 添加收藏 |
| 收藏 | `/api/v1/favorite/list` | GET | 获取收藏列表 |

## 🚀 快速开始

### 环境要求

- Go 1.21+
- MySQL 5.7+
- Redis 6.0+

### 1. 克隆项目

```bash
git clone https://gitee.com/llinfan/bookstore-go
```

### 2. 后端配置

```bash
# 安装依赖
go mod tidy

# 配置数据库

# 编辑配置文件，设置数据库连接信息
vim conf/config.yaml #替换为自己的信息

server:
  port: 8080        # 用户端端口
  admin_port: 8081  # 管理员端口

database:
  host: 127.0.0.1
  port: 3306
  user: root
  password: your_password
  name: bookstore

redis:
  host: 127.0.0.1
  port: 6379
  password: ""
  db: 0

# 初始化数据库
source sql/bookstore.sql
source sql/mock.sql

# 编译服务
make bookstore-manager

# 启动后端服务
./bin/bookstore-manager

```

### 3. 前端配置（先忽略）

```bash
# 进入前端目录
cd bookstore-fronted

# 安装依赖
npm install

# 启动开发服务器
npm start
```

### 4. 访问应用

- **用户端后端API**: http://localhost:8080
- **管理员后端API**: http://localhost:8081

## 📁 项目结构

```
bookstore-web/
├── cmd/                    # 程序入口
│   ├── bookstore-manager/  # 用户端服务入口
│   └── admin-manager/      # 管理员服务入口
├── model/                  # 数据模型
├── service/                # 业务逻辑层
├── repository/             # 数据访问层
├── web/                    # Web层
│   ├── controller/         # 控制器
│   │   ├── book.go        # 用户端图书控制器
│   │   ├── admin_book.go  # 管理员图书控制器
│   │   ├── admin_order.go # 管理员订单控制器
│   │   └── admin_user.go  # 管理员用户控制器
│   ├── router/            # 路由配置
│   │   ├── router.go      # 用户端路由
│   │   └── admin_router.go # 管理员路由
│   └── middleware/        # 中间件
└── conf/                  # 配置文件
```

## 🔒 安全特性

- **密码加密**: 使用bcrypt进行密码哈希
- **JWT认证**: 基于Token的无状态认证
- **SQL注入防护**: 使用GORM参数化查询
- **CORS配置**: 跨域请求安全配置
- **输入验证**: 请求参数严格验证

## 🚀 部署指南

### 生产环境部署

1. 配置生产环境数据库
2. 设置环境变量
3. 使用PM2或systemd管理进程
4. 配置Nginx反向代理
5. 启用HTTPS

```
TODO:
1、页面和体验的交互优化
2、加入更多技术栈，如MQ、OSS、Kafka等中间件
3、将项目改为 RPC 框架实现
4、是否能改成秒杀相关的系统？
5、……

```

## 📞 联系方式

- 项目维护者: [Mike Lin]
- 邮箱: 931002611@qq.com (一般晚上才会处理信息，有事情辛苦留言 ~)

---

如果这个项目对您有帮助，或者您觉得代码写得还不错，谢谢请我喝杯奶茶！您的支持是我持续开源的动力 💪

<div align="center">

**微信支付** (推荐) | **支付宝**
---|---
<img src="./pic/wechat.jpg" width="200" height="200" /> | <img src="./pic/zhifubao.jpg" width="200" height="200" />

</div>
