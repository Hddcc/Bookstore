package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"bookstore/config"
	"bookstore/global"
	"bookstore/web/router"
)

func init() {
	// 初始化全局变量
	global.DBClient = nil
	global.RedisClient = nil
}

func main() {
	// 初始化配置
	config.InitConfig("conf/config.yaml")
	cfg := config.AppConfig

	// 初始化数据库连接
	global.InitMySQL()

	// 初始化Redis连接
	global.InitRedis()

	// 设置优雅关闭
	setupGracefulShutdown()

	// 启动管理员服务
	r := router.InitAdminRouter()
	addr := fmt.Sprintf(":%d", cfg.Server.AdminPort) // 使用管理员端口

	server := &http.Server{
		Addr:    addr,
		Handler: r,
		// 添加超时配置
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  15 * time.Second,
	}

	// 信号监听
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM, syscall.SIGHUP, syscall.SIGQUIT)

	// 在goroutine中启动服务器
	go func() {
		log.Printf("🚀 管理员系统启动成功，端口: %d", cfg.Server.AdminPort)
		log.Printf("📖 访问地址: http://localhost:%d", cfg.Server.AdminPort)
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("管理员系统启动失败: %v", err)
		}
	}()

	// 等待中断信号以优雅地关闭服务器
	sig := <-quit
	log.Printf("收到信号: %v", sig)

	switch sig {
	case syscall.SIGINT:
		log.Println("收到 SIGINT (Ctrl+C)，正在关闭服务器...")
	case syscall.SIGTERM:
		log.Println("收到 SIGTERM，正在关闭服务器...")
	case syscall.SIGHUP:
		log.Println("收到 SIGHUP，正在关闭服务器...")
	case syscall.SIGQUIT:
		log.Println("收到 SIGQUIT，正在关闭服务器...")
	default:
		log.Printf("收到信号 %v，正在关闭服务器...", sig)
	}

	// 创建5秒超时的context用于优雅关闭
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	// 关闭HTTP服务器
	log.Println("正在关闭HTTP服务器...")
	if err := server.Shutdown(ctx); err != nil {
		log.Printf("服务器强制关闭: %v", err)
	} else {
		log.Println("HTTP服务器优雅停止")
	}

	// 清理资源
	log.Println("正在清理资源...")
	cleanupResources()

	log.Println("管理员系统退出成功")
}

// setupGracefulShutdown 设置优雅关闭
func setupGracefulShutdown() {
	// 可以在这里添加其他初始化逻辑
}

// cleanupResources 清理资源
func cleanupResources() {
	// 关闭数据库连接
	if global.DBClient != nil {
		log.Println("正在关闭数据库连接...")
		global.CloseDB()
	}

	// 关闭Redis连接
	if global.RedisClient != nil {
		log.Println("正在关闭Redis连接...")
		global.CloseRedis()
	}

	// 等待一小段时间确保所有资源都被正确释放
	time.Sleep(100 * time.Millisecond)
	log.Println("所有资源已清理完成")
}
