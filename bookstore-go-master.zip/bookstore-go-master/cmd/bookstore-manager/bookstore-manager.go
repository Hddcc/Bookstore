package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"bookstore/config"
	"bookstore/global"
	"bookstore/web/router"
)

func init() {
	// 初始化全局变量
	global.DBClient = nil
	global.RedisClient = nil
}

func main() {
	// 初始化配置
	config.InitConfig("conf/config.yaml")
	cfg := config.AppConfig

	// 初始化数据库连接
	global.InitMySQL()

	// 初始化Redis连接
	global.InitRedis()

	// 设置优雅关闭
	setupGracefulShutdown()

	// 启动 web 服务
	r := router.InitRouter()
	addr := fmt.Sprintf(":%d", cfg.Server.Port)

	server := &http.Server{
		Addr:    addr,
		Handler: r,
		// 添加超时配置
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  15 * time.Second,
	}

	// 信号监听
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM, syscall.SIGHUP, syscall.SIGQUIT)

	// 在goroutine中启动服务器
	go func() {
		log.Printf("Server running at http://localhost%s", addr)
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Failed to run server: %v", err)
		}
	}()

	// 等待中断信号以优雅地关闭服务器
	sig := <-quit
	log.Printf("Received signal: %v", sig)

	switch sig {
	case syscall.SIGINT:
		log.Println("Received SIGINT (Ctrl+C), shutting down server...")
	case syscall.SIGTERM:
		log.Println("Received SIGTERM, shutting down server...")
	case syscall.SIGHUP:
		log.Println("Received SIGHUP, shutting down server...")
	case syscall.SIGQUIT:
		log.Println("Received SIGQUIT, shutting down server...")
	default:
		log.Printf("Received signal %v, shutting down server...", sig)
	}

	// 创建5秒超时的context用于优雅关闭
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	// 关闭HTTP服务器
	log.Println("Shutting down HTTP server...")
	if err := server.Shutdown(ctx); err != nil {
		log.Printf("Server forced to shutdown: %v", err)
	} else {
		log.Println("HTTP server gracefully stopped")
	}

	// 清理资源
	log.Println("Cleaning up resources...")
	cleanupResources()

	// 等待一小段时间确保所有资源都被正确释放
	time.Sleep(100 * time.Millisecond)
	log.Println("Server exited successfully")

	// 强制退出程序
	os.Exit(0)
}

// setupGracefulShutdown 设置优雅关闭
func setupGracefulShutdown() {
	// 可以在这里添加其他初始化逻辑
}

// cleanupResources 清理资源
func cleanupResources() {
	// 关闭数据库连接
	if global.DBClient != nil {
		log.Println("Closing database connection...")
		global.CloseDB()
	}

	// 关闭Redis连接
	if global.RedisClient != nil {
		log.Println("Closing Redis connection...")
		global.CloseRedis()
	}

	// 等待一小段时间确保所有资源都被正确释放
	time.Sleep(100 * time.Millisecond)
	log.Println("All resources cleaned up")
}
