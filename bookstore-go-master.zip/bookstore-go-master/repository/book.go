package repository

import (
	"bookstore/global"
	"bookstore/model"

	"gorm.io/gorm"
)

// BookDAO 书籍数据访问对象
type BookDAO struct {
	db *gorm.DB
}

// NewBookDAO 创建新的书籍DAO实例
func NewBookDAO() *BookDAO {
	return &BookDAO{
		db: global.GetDB(),
	}
}

// GetAllBooks 获取所有书籍
func (b *BookDAO) GetAllBooks() ([]*model.Book, error) {
	var books []*model.Book
	err := b.db.Find(&books).Error
	return books, err
}

// GetBooksByPage 分页获取书籍（只返回上架状态）
func (b *BookDAO) GetBooksByPage(page, pageSize int) ([]*model.Book, int64, error) {
	var books []*model.Book
	var total int64

	// 获取总数
	err := b.db.Model(&model.Book{}).Where("status = ?", 1).Count(&total).Error
	if err != nil {
		return nil, 0, err
	}

	// 分页查询
	offset := (page - 1) * pageSize
	err = b.db.Where("status = ?", 1).Offset(offset).Limit(pageSize).Find(&books).Error
	return books, total, err
}

// GetBooksByPageForAdmin 分页获取书籍（管理员用，不过滤状态）
func (b *BookDAO) GetBooksByPageForAdmin(page, pageSize int) ([]*model.Book, int64, error) {
	var books []*model.Book
	var total int64

	// 获取总数
	err := b.db.Model(&model.Book{}).Count(&total).Error
	if err != nil {
		return nil, 0, err
	}

	// 分页查询
	offset := (page - 1) * pageSize
	err = b.db.Offset(offset).Limit(pageSize).Find(&books).Error
	return books, total, err
}

// GetBooksByPageForAdminWithSearch 分页获取书籍（管理员用，支持搜索）
func (b *BookDAO) GetBooksByPageForAdminWithSearch(page, pageSize int, title, author, bookType string, status *int) ([]*model.Book, int64, error) {
	var books []*model.Book
	var total int64

	// 构建查询条件
	query := b.db.Model(&model.Book{})

	// 添加搜索条件
	if title != "" {
		query = query.Where("title LIKE ?", "%"+title+"%")
	}
	if author != "" {
		query = query.Where("author LIKE ?", "%"+author+"%")
	}
	if bookType != "" {
		query = query.Where("type = ?", bookType)
	}
	if status != nil {
		query = query.Where("status = ?", *status)
	}

	// 获取总数
	err := query.Count(&total).Error
	if err != nil {
		return nil, 0, err
	}

	// 分页查询
	offset := (page - 1) * pageSize
	err = query.Offset(offset).Limit(pageSize).Find(&books).Error
	if err != nil {
	} else {
	}
	return books, total, err
}

// GetHotBooks 获取热销书籍（只返回上架状态）
func (b *BookDAO) GetHotBooks(limit int) ([]*model.Book, error) {
	var books []*model.Book
	err := b.db.Where("status = ?", 1).Order("sale DESC").Limit(limit).Find(&books).Error
	if err != nil {
	} else {
	}
	return books, err
}

// GetNewBooks 获取新书（只返回上架状态）
func (b *BookDAO) GetNewBooks(limit int) ([]*model.Book, error) {
	var books []*model.Book
	err := b.db.Where("status = ?", 1).Order("created_at DESC").Limit(limit).Find(&books).Error
	if err != nil {
	} else {
	}
	return books, err
}

// GetBookByID 根据ID获取书籍（只返回上架状态）
func (b *BookDAO) GetBookByID(id int) (*model.Book, error) {
	var book model.Book
	err := b.db.Where("status = ?", 1).First(&book, id).Error
	if err != nil {
	} else {
	}
	return &book, err
}

// GetBookByIDForAdmin 根据ID获取书籍（管理员用，不过滤状态）
func (b *BookDAO) GetBookByIDForAdmin(id int) (*model.Book, error) {
	var book model.Book
	err := b.db.First(&book, id).Error
	if err != nil {
	} else {
	}
	return &book, err
}

// GetBooksByType 根据类型获取书籍（只返回上架状态）
func (b *BookDAO) GetBooksByType(bookType string) ([]*model.Book, error) {
	var books []*model.Book
	err := b.db.Where("status = ? AND type = ?", 1, bookType).Find(&books).Error
	if err != nil {
	} else {
	}
	return books, err
}

// SearchBooks 搜索书籍（只返回上架状态）
func (b *BookDAO) SearchBooks(keyword string) ([]*model.Book, error) {
	var books []*model.Book
	err := b.db.Where("status = ? AND (title LIKE ? OR author LIKE ? OR description LIKE ?)",
		1, "%"+keyword+"%", "%"+keyword+"%", "%"+keyword+"%").Find(&books).Error
	if err != nil {
	} else {
	}
	return books, err
}

// SearchBooksWithPagination 分页搜索书籍（只返回上架状态）
func (b *BookDAO) SearchBooksWithPagination(keyword string, page, pageSize int) ([]*model.Book, int64, error) {
	var books []*model.Book
	var total int64

	// 构建搜索条件（只搜索上架状态）
	searchCondition := b.db.Where("status = ? AND (title LIKE ? OR author LIKE ? OR description LIKE ?)",
		1, "%"+keyword+"%", "%"+keyword+"%", "%"+keyword+"%")

	// 获取总数
	err := searchCondition.Model(&model.Book{}).Count(&total).Error
	if err != nil {
		return nil, 0, err
	}

	// 分页查询
	offset := (page - 1) * pageSize
	err = searchCondition.Offset(offset).Limit(pageSize).Find(&books).Error
	if err != nil {
	} else {
	}
	return books, total, err
}

// CreateBook 创建书籍
func (b *BookDAO) CreateBook(book *model.Book) error {
	err := b.db.Create(book).Error
	if err != nil {
	} else {
	}
	return err
}

// UpdateBook 更新书籍
func (b *BookDAO) UpdateBook(book *model.Book) error {
	err := b.db.Save(book).Error
	if err != nil {
	} else {
	}
	return err
}

// DeleteBook 删除书籍
func (b *BookDAO) DeleteBook(id int) error {
	err := b.db.Delete(&model.Book{}, id).Error
	if err != nil {
	} else {
	}
	return err
}
