package repository

import (
	"bookstore/model"

	"gorm.io/gorm"
)

// CarouselDAO 轮播图数据访问对象
type CarouselDAO struct {
	db *gorm.DB
}

// NewCarouselDAO 创建新的轮播图DAO实例
func NewCarouselDAO(db *gorm.DB) *CarouselDAO {
	return &CarouselDAO{
		db: db,
	}
}

// GetAllCarousels 获取所有轮播图
func (c *CarouselDAO) GetAllCarousels() ([]*model.Carousel, error) {
	var carousels []*model.Carousel
	err := c.db.Find(&carousels).Error
	return carousels, err
}

// GetActiveCarousels 获取活跃的轮播图
func (c *CarouselDAO) GetActiveCarousels() ([]*model.Carousel, error) {
	var carousels []*model.Carousel
	err := c.db.Where("is_active = ?", true).Order("sort_order ASC").Find(&carousels).Error
	if err != nil {
	} else {
	}
	return carousels, err
}

// GetCarouselByID 根据ID获取轮播图
func (c *CarouselDAO) GetCarouselByID(id int) (*model.Carousel, error) {
	var carousel model.Carousel
	err := c.db.First(&carousel, id).Error
	if err != nil {
	} else {
	}
	return &carousel, err
}

// CreateCarousel 创建轮播图
func (c *CarouselDAO) CreateCarousel(carousel *model.Carousel) error {
	err := c.db.Create(carousel).Error
	if err != nil {
	} else {
	}
	return err
}

// UpdateCarousel 更新轮播图
func (c *CarouselDAO) UpdateCarousel(carousel *model.Carousel) error {
	err := c.db.Save(carousel).Error
	if err != nil {
	} else {
	}
	return err
}

// DeleteCarousel 删除轮播图
func (c *CarouselDAO) DeleteCarousel(id int) error {
	err := c.db.Delete(&model.Carousel{}, id).Error
	if err != nil {
	} else {
	}
	return err
}
