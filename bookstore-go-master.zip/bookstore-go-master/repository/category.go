package repository

import (
	"bookstore/global"
	"bookstore/model"

	"gorm.io/gorm"
)

// CategoryDAO 分类数据访问对象
type CategoryDAO struct {
	db *gorm.DB
}

// NewCategoryDAO 创建新的分类DAO实例
func NewCategoryDAO() *CategoryDAO {
	return &CategoryDAO{
		db: global.GetDB(),
	}
}

// GetAllCategories 获取所有分类
func (c *CategoryDAO) GetAllCategories() ([]*model.Category, error) {
	var categories []*model.Category
	err := c.db.Find(&categories).Error
	return categories, err
}

// GetCategoryByID 根据ID获取分类
func (c *CategoryDAO) GetCategoryByID(id int) (*model.Category, error) {
	var category model.Category
	err := c.db.First(&category, id).Error
	if err != nil {
	} else {
	}
	return &category, err
}

// CreateCategory 创建分类
func (c *CategoryDAO) CreateCategory(category *model.Category) error {
	err := c.db.Create(category).Error
	if err != nil {
	} else {
	}
	return err
}

// UpdateCategory 更新分类
func (c *CategoryDAO) UpdateCategory(category *model.Category) error {
	err := c.db.Save(category).Error
	if err != nil {
	} else {
	}
	return err
}

// DeleteCategory 删除分类
func (c *CategoryDAO) DeleteCategory(id int) error {
	err := c.db.Delete(&model.Category{}, id).Error
	if err != nil {
	} else {
	}
	return err
}
