package repository

import (
	"bookstore/global"
	"bookstore/model"

	"gorm.io/gorm"
)

// FavoriteDAO 收藏数据访问对象
type FavoriteDAO struct {
	db *gorm.DB
}

// NewFavoriteDAO 创建新的收藏DAO实例
func NewFavoriteDAO() *FavoriteDAO {
	return &FavoriteDAO{
		db: global.GetDB(),
	}
}

// AddFavorite 添加收藏
func (f *FavoriteDAO) AddFavorite(userID int, bookID int) error {
	favorite := &model.Favorite{
		UserID: userID,
		BookID: bookID,
	}
	err := f.db.Create(favorite).Error
	if err != nil {
	} else {
	}
	return err
}

// RemoveFavorite 移除收藏
func (f *FavoriteDAO) RemoveFavorite(userID int, bookID int) error {
	err := f.db.Where("user_id = ? AND book_id = ?", userID, bookID).Delete(&model.Favorite{}).Error
	if err != nil {
	} else {
	}
	return err
}

// CheckFavorite 检查是否已收藏
func (f *FavoriteDAO) CheckFavorite(userID int, bookID int) (bool, error) {
	var count int64
	err := f.db.Model(&model.Favorite{}).Where("user_id = ? AND book_id = ?", userID, bookID).Count(&count).Error
	if err != nil {
		return false, err
	}
	isFavorited := count > 0
	return isFavorited, nil
}

// GetUserFavorites 获取用户的收藏列表
func (f *FavoriteDAO) GetUserFavorites(userID int) ([]*model.Favorite, error) {
	var favorites []*model.Favorite
	err := f.db.Preload("Book").Where("user_id = ?", userID).Find(&favorites).Error
	if err != nil {
	} else {
	}
	return favorites, err
}

// GetUserFavoriteCount 获取用户的收藏数量
func (f *FavoriteDAO) GetUserFavoriteCount(userID int) (int64, error) {
	var count int64
	err := f.db.Model(&model.Favorite{}).Where("user_id = ?", userID).Count(&count).Error
	if err != nil {
	} else {
	}
	return count, err
}
