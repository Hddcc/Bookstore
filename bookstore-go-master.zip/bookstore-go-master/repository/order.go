package repository

import (
	"bookstore/global"
	"bookstore/model"
	"fmt"
	"time"

	"gorm.io/gorm"
)

// OrderDAO 订单数据访问对象
type OrderDAO struct {
	db *gorm.DB
}

// NewOrderDAO 创建新的订单DAO实例
func NewOrderDAO() *OrderDAO {
	return &OrderDAO{
		db: global.GetDB(),
	}
}

// CreateOrder 创建订单
func (o *OrderDAO) CreateOrder(order *model.Order) error {
	err := o.db.Create(order).Error
	if err != nil {
	} else {
	}
	return err
}

// GetOrderByID 根据ID获取订单
func (o *OrderDAO) GetOrderByID(id int) (*model.Order, error) {
	var order model.Order
	err := o.db.Preload("OrderItems.Book").First(&order, id).Error
	if err != nil {
	} else {
	}
	return &order, err
}

// GetOrderByOrderNo 根据订单号获取订单
func (o *OrderDAO) GetOrderByOrderNo(orderNo string) (*model.Order, error) {
	var order model.Order
	err := o.db.Preload("OrderItems.Book").Where("order_no = ?", orderNo).First(&order).Error
	if err != nil {
	} else {
	}
	return &order, err
}

// GetUserOrders 获取用户的订单列表
func (o *OrderDAO) GetUserOrders(userID int, page, pageSize int) ([]*model.Order, int64, error) {
	var orders []*model.Order
	var total int64

	// 获取总数
	err := o.db.Model(&model.Order{}).Where("user_id = ?", userID).Count(&total).Error
	if err != nil {
		return nil, 0, err
	}

	// 分页查询
	offset := (page - 1) * pageSize
	err = o.db.Preload("OrderItems.Book").
		Where("user_id = ?", userID).
		Order("created_at DESC").
		Offset(offset).
		Limit(pageSize).
		Find(&orders).Error

	if err != nil {
	} else {
	}
	return orders, total, err
}

// UpdateOrderStatus 更新订单状态
func (o *OrderDAO) UpdateOrderStatus(orderID int, status int) error {
	err := o.db.Model(&model.Order{}).Where("id = ?", orderID).Update("status", status).Error
	if err != nil {
	} else {
	}
	return err
}

// MarkOrderAsPaid 标记订单为已支付
func (o *OrderDAO) MarkOrderAsPaid(orderID int) error {
	now := time.Now()
	err := o.db.Model(&model.Order{}).
		Where("id = ?", orderID).
		Updates(map[string]interface{}{
			"status":       1,
			"is_paid":      true,
			"payment_time": &now,
		}).Error
	if err != nil {
	} else {
	}
	return err
}

// GenerateOrderNo 生成订单号
func (o *OrderDAO) GenerateOrderNo() string {
	orderNo := fmt.Sprintf("ORD%d", time.Now().UnixNano())
	return orderNo
}

// CreateOrderWithItems 创建订单和订单项
func (o *OrderDAO) CreateOrderWithItems(order *model.Order, items []*model.OrderItem) error {
	err := o.db.Transaction(func(tx *gorm.DB) error {
		// 创建订单
		if err := tx.Create(order).Error; err != nil {
			return err
		}

		// 创建订单项
		for _, item := range items {
			item.OrderID = order.ID
			if err := tx.Create(item).Error; err != nil {
				return err
			}
		}

		return nil
	})
	if err != nil {
	} else {
	}
	return err
}

// GetOrderStatistics 获取订单统计信息
func (o *OrderDAO) GetOrderStatistics(userID int) (map[string]interface{}, error) {
	var stats struct {
		TotalOrders   int64   `json:"total_orders"`
		TotalAmount   float64 `json:"total_amount"`
		PaidOrders    int64   `json:"paid_orders"`
		PendingOrders int64   `json:"pending_orders"`
	}

	err := o.db.Model(&model.Order{}).
		Select("COUNT(*) as total_orders, SUM(total_amount) as total_amount").
		Where("user_id = ?", userID).
		Scan(&stats).Error
	if err != nil {
		return nil, err
	}

	err = o.db.Model(&model.Order{}).
		Where("user_id = ? AND is_paid = ?", userID, true).
		Count(&stats.PaidOrders).Error
	if err != nil {
		return nil, err
	}

	err = o.db.Model(&model.Order{}).
		Where("user_id = ? AND is_paid = ?", userID, false).
		Count(&stats.PendingOrders).Error
	if err != nil {
		return nil, err
	}

	return map[string]interface{}{
		"total_orders":   stats.TotalOrders,
		"total_amount":   stats.TotalAmount,
		"paid_orders":    stats.PaidOrders,
		"pending_orders": stats.PendingOrders,
	}, nil
}
