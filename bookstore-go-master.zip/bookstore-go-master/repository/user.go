package repository

import (
	"bookstore/global"
	"bookstore/model"

	"gorm.io/gorm"
)

// UserDAO 用户数据访问对象
type UserDAO struct {
	db *gorm.DB
}

// NewUserDAO 创建新的用户DAO实例
func NewUserDAO() *UserDAO {
	return &UserDAO{
		db: global.GetDB(),
	}
}

// GetUserByID 根据ID获取用户
func (u *UserDAO) GetUserByID(id int) (*model.User, error) {
	var user model.User
	err := u.db.First(&user, id).Error
	if err != nil {
	} else {
	}
	return &user, err
}

// GetUserByUsername 根据用户名获取用户
func (u *UserDAO) GetUserByUsername(username string) (*model.User, error) {
	var user model.User
	err := u.db.Where("username = ?", username).First(&user).Error
	if err != nil {
	} else {
	}
	return &user, err
}

// CreateUser 创建用户
func (u *UserDAO) CreateUser(user *model.User) error {
	err := u.db.Create(user).Error
	if err != nil {
	} else {
	}
	return err
}

// UpdateUser 更新用户
func (u *UserDAO) UpdateUser(user *model.User) error {
	err := u.db.Save(user).Error
	if err != nil {
	} else {
	}
	return err
}

// DeleteUser 删除用户
func (u *UserDAO) DeleteUser(id int) error {
	err := u.db.Delete(&model.User{}, id).Error
	if err != nil {
	} else {
	}
	return err
}

// CheckUserExists 检查用户是否存在
func (u *UserDAO) CheckUserExists(username, phone, email string) (bool, error) {
	var count int64

	// 检查用户名是否存在
	err := u.db.Model(&model.User{}).Where("username = ?", username).Count(&count).Error
	if err != nil {
		return false, err
	}
	if count > 0 {
		return true, nil
	}

	// 检查手机号是否存在
	err = u.db.Model(&model.User{}).Where("phone = ?", phone).Count(&count).Error
	if err != nil {
		return false, err
	}
	if count > 0 {
		return true, nil
	}

	// 检查邮箱是否存在
	err = u.db.Model(&model.User{}).Where("email = ?", email).Count(&count).Error
	if err != nil {
		return false, err
	}
	return count > 0, nil
}

// GetUserList 获取用户列表
func (u *UserDAO) GetUserList(page, pageSize int) ([]*model.User, int64, error) {
	var users []*model.User
	var total int64

	// 获取总数
	err := u.db.Model(&model.User{}).Count(&total).Error
	if err != nil {
		return nil, 0, err
	}

	// 分页查询
	offset := (page - 1) * pageSize
	err = u.db.Offset(offset).Limit(pageSize).Find(&users).Error
	if err != nil {
	} else {
	}
	return users, total, err
}
