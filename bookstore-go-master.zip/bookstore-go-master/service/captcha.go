package service

import (
	"context"
	"fmt"
	"time"

	"bookstore/global"

	"github.com/mojocn/base64Captcha"
)

// CaptchaService 验证码服务
type CaptchaService struct {
	store base64Captcha.Store
}

// NewCaptchaService 创建新的验证码服务实例
func NewCaptchaService() *CaptchaService {
	return &CaptchaService{
		store: base64Captcha.DefaultMemStore,
	}
}

// CaptchaResponse 验证码响应结构
type CaptchaResponse struct {
	CaptchaID     string `json:"captcha_id"`
	CaptchaBase64 string `json:"captcha_base64"`
}

// GenerateCaptcha 生成验证码
func (c *CaptchaService) GenerateCaptcha() (*CaptchaResponse, error) {
	// 配置验证码参数
	driver := base64Captcha.NewDriverDigit(
		80,  // 高度
		240, // 宽度
		4,   // 验证码长度
		0.7, // 干扰强度
		80,  // 干扰数量
	)

	// 生成验证码
	captcha := base64Captcha.NewCaptcha(driver, c.store)
	id, b64s, answer, err := captcha.Generate()
	if err != nil {
		return nil, err
	}

	// 将验证码答案存储到Redis，设置5分钟过期
	ctx := context.Background()
	redisKey := fmt.Sprintf("captcha:%s", id)
	err = global.RedisClient.Set(ctx, redisKey, answer, 5*time.Minute).Err()
	if err != nil {
		return nil, err
	}

	return &CaptchaResponse{
		CaptchaID:     id,
		CaptchaBase64: b64s,
	}, nil
}

// VerifyCaptcha 验证验证码
func (c *CaptchaService) VerifyCaptcha(captchaID, captchaValue string) bool {
	if captchaID == "" || captchaValue == "" {
		return false
	}

	// 从Redis获取验证码答案
	ctx := context.Background()
	redisKey := fmt.Sprintf("captcha:%s", captchaID)
	storedAnswer, err := global.RedisClient.Get(ctx, redisKey).Result()
	if err != nil {
		return false
	}

	// 比较用户输入的验证码和存储的答案
	isValid := storedAnswer == captchaValue

	// 验证成功后删除Redis中的验证码
	if isValid {
		global.RedisClient.Del(ctx, redisKey)
	}

	return isValid
}

// CleanExpiredCaptcha 清理过期的验证码
func (c *CaptchaService) CleanExpiredCaptcha() {
	ctx := context.Background()
	keys, err := global.RedisClient.Keys(ctx, "captcha:*").Result()
	if err != nil {
		return
	}

	for _, key := range keys {
		// Redis会自动清理过期的key，这里可以添加额外的清理逻辑
		// 比如检查TTL等
		ttl, err := global.RedisClient.TTL(ctx, key).Result()
		if err == nil && ttl <= 0 {
			global.RedisClient.Del(ctx, key)
		}
	}
}
