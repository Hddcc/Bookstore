package service

import (
	"bookstore/model"
	"bookstore/repository"
)

type CarouselService struct {
	CarouselDB *repository.CarouselDAO
}

func NewCarouselService(carouselDB *repository.CarouselDAO) *CarouselService {
	return &CarouselService{
		CarouselDB: carouselDB,
	}
}

// GetActiveCarousels 获取激活的轮播图
func (c *CarouselService) GetActiveCarousels() ([]*model.Carousel, error) {
	return c.CarouselDB.GetActiveCarousels()
}

// GetCarouselByID 根据ID获取轮播图
func (c *CarouselService) GetCarouselByID(id int) (*model.Carousel, error) {
	return c.CarouselDB.GetCarouselByID(id)
}

// CreateCarousel 创建轮播图
func (c *CarouselService) CreateCarousel(carousel *model.Carousel) error {
	return c.CarouselDB.CreateCarousel(carousel)
}

// UpdateCarousel 更新轮播图
func (c *CarouselService) UpdateCarousel(carousel *model.Carousel) error {
	return c.CarouselDB.UpdateCarousel(carousel)
}

// DeleteCarousel 删除轮播图
func (c *CarouselService) DeleteCarousel(id int) error {
	return c.CarouselDB.DeleteCarousel(id)
}

// GetAllCarousels 获取所有轮播图
func (c *CarouselService) GetAllCarousels() ([]*model.Carousel, error) {
	return c.CarouselDB.GetAllCarousels()
}
