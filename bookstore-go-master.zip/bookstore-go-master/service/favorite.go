package service

import (
	"bookstore/model"
	"bookstore/repository"
)

type FavoriteService struct {
	favoriteDAO *repository.FavoriteDAO
}

func NewFavoriteService(favoriteDAO *repository.FavoriteDAO) *FavoriteService {
	return &FavoriteService{
		favoriteDAO: favoriteDAO,
	}
}

// 添加收藏
func (f *FavoriteService) AddFavorite(userID, bookID int) error {
	return f.favoriteDAO.AddFavorite(userID, bookID)
}

// 取消收藏
func (f *FavoriteService) RemoveFavorite(userID, bookID int) error {
	return f.favoriteDAO.RemoveFavorite(userID, bookID)
}

// 检查是否已收藏
func (f *FavoriteService) IsFavorited(userID, bookID int) (bool, error) {
	return f.favoriteDAO.CheckFavorite(userID, bookID)
}

// 获取用户收藏列表
func (f *FavoriteService) GetUserFavorites(userID int, page, pageSize int, timeFilter string) ([]*model.Favorite, int64, error) {
	favorites, err := f.favoriteDAO.GetUserFavorites(userID)
	if err != nil {
		return nil, 0, err
	}

	// 简单的分页实现
	total := int64(len(favorites))
	start := (page - 1) * pageSize
	end := start + pageSize

	if start >= len(favorites) {
		return []*model.Favorite{}, total, nil
	}

	if end > len(favorites) {
		end = len(favorites)
	}

	return favorites[start:end], total, nil
}

// 获取用户收藏数量
func (f *FavoriteService) GetUserFavoriteCount(userID int) (int64, error) {
	return f.favoriteDAO.GetUserFavoriteCount(userID)
}
