package controller

import (
	"bookstore/global"
	"bookstore/model"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
)

type AdminDashboardController struct{}

func NewAdminDashboardController() *AdminDashboardController {
	return &AdminDashboardController{}
}

// DashboardStats 仪表盘统计数据
type DashboardStats struct {
	TotalBooks   int64   `json:"total_books"`
	TotalOrders  int64   `json:"total_orders"`
	TotalUsers   int64   `json:"total_users"`
	TotalRevenue float64 `json:"total_revenue"`
	RecentBooks  []Book  `json:"recent_books"`
}

// Book 简化的图书信息
type Book struct {
	ID        int    `json:"id"`
	Title     string `json:"title"`
	Author    string `json:"author"`
	Price     int    `json:"price"`
	CoverURL  string `json:"cover_url"`
	CreatedAt string `json:"created_at"`
}

// GetDashboardStats 获取仪表盘统计数据
func (c *AdminDashboardController) GetDashboardStats(ctx *gin.Context) {
	var stats DashboardStats

	// 获取图书总数
	global.DBClient.Model(&model.Book{}).Count(&stats.TotalBooks)

	// 获取订单总数
	global.DBClient.Model(&model.Order{}).Count(&stats.TotalOrders)

	// 获取用户总数
	global.DBClient.Model(&model.User{}).Count(&stats.TotalUsers)

	// 获取总收入（已支付的订单）
	var totalRevenue int64
	global.DBClient.Model(&model.Order{}).
		Where("is_paid = ?", true).
		Select("COALESCE(SUM(total_amount), 0)").
		Scan(&totalRevenue)
	stats.TotalRevenue = float64(totalRevenue) // 已经是元为单位

	// 获取最近3天添加的图书
	var recentBooks []model.Book
	threeDaysAgo := time.Now().AddDate(0, 0, -3)
	global.DBClient.Where("created_at >= ?", threeDaysAgo).
		Order("created_at DESC").
		Limit(10).
		Find(&recentBooks)

	// 转换为简化的图书信息
	for _, book := range recentBooks {
		stats.RecentBooks = append(stats.RecentBooks, Book{
			ID:        book.ID,
			Title:     book.Title,
			Author:    book.Author,
			Price:     book.Price,
			CoverURL:  book.CoverURL,
			CreatedAt: book.CreatedAt.Format("2006-01-02 15:04:05"),
		})
	}

	ctx.JSON(http.StatusOK, gin.H{
		"code":    0,
		"message": "获取统计数据成功",
		"data":    stats,
	})
}
