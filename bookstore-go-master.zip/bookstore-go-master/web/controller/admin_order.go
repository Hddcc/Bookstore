package controller

import (
	"bookstore/service"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

type AdminOrderController struct {
	orderService *service.OrderService
}

func NewAdminOrderController() *AdminOrderController {
	return &AdminOrderController{
		orderService: service.NewOrderService(),
	}
}

// GetOrderList 获取订单列表
func (c *AdminOrderController) GetOrderList(ctx *gin.Context) {
	ctx.JSON(http.StatusOK, gin.H{
		"code":    0,
		"message": "获取订单列表成功",
		"data":    []interface{}{},
	})
}

// GetOrderByID 根据ID获取订单
func (c *AdminOrderController) GetOrderByID(ctx *gin.Context) {
	idStr := ctx.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"code":    -1,
			"message": "ID参数错误",
		})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"code":    0,
		"message": "获取订单成功",
		"data":    gin.H{"id": id},
	})
}

// UpdateOrderStatus 更新订单状态
func (c *AdminOrderController) UpdateOrderStatus(ctx *gin.Context) {
	idStr := ctx.Param("id")
	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"code":    -1,
			"message": "ID参数错误",
		})
		return
	}

	var req struct {
		Status int `json:"status" binding:"required"`
	}
	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"code":    -1,
			"message": "参数错误: " + err.Error(),
		})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"code":    0,
		"message": "更新订单状态成功",
		"data":    gin.H{"id": id, "status": req.Status},
	})
}
