package controller

import (
	"net/http"

	"bookstore/service"

	"github.com/gin-gonic/gin"
)

// CaptchaController 验证码控制器
type CaptchaController struct {
	CaptchaService *service.CaptchaService
}

// NewCaptchaController 创建新的验证码控制器实例
func NewCaptchaController() *CaptchaController {
	return &CaptchaController{
		CaptchaService: service.NewCaptchaService(),
	}
}

// GenerateCaptcha 生成验证码
func (c *CaptchaController) GenerateCaptcha(ctx *gin.Context) {
	// 生成验证码
	captchaResponse, err := c.CaptchaService.GenerateCaptcha()
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, gin.H{
			"code":    -1,
			"message": "生成验证码失败",
			"error":   err.Error(),
		})
		return
	}

	ctx.JSON(http.StatusOK, gin.H{
		"code":    0,
		"data":    captchaResponse,
		"message": "验证码生成成功",
	})
}

// VerifyCaptcha 验证验证码
func (c *CaptchaController) VerifyCaptcha(ctx *gin.Context) {
	var req struct {
		CaptchaID    string `json:"captcha_id" binding:"required"`
		CaptchaValue string `json:"captcha_value" binding:"required"`
	}

	if err := ctx.ShouldBindJSON(&req); err != nil {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"code":    -1,
			"message": "请求参数错误",
			"error":   err.Error(),
		})
		return
	}

	// 验证验证码
	isValid := c.CaptchaService.VerifyCaptcha(req.CaptchaID, req.CaptchaValue)

	if isValid {
		ctx.JSON(http.StatusOK, gin.H{
			"code":    0,
			"message": "验证码正确",
		})
	} else {
		ctx.JSON(http.StatusBadRequest, gin.H{
			"code":    -1,
			"message": "验证码错误",
		})
	}
}
