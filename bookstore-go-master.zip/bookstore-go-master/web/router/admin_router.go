package router

import (
	"bookstore/web/controller"
	"bookstore/web/middleware"

	"github.com/gin-gonic/gin"
)

// InitAdminRouter 初始化管理员路由
func InitAdminRouter() *gin.Engine {
	r := gin.Default()

	// 添加CORS中间件
	r.Use(func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Origin, Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization")
		c.Header("Access-Control-Expose-Headers", "Content-Length")
		c.Header("Access-Control-Allow-Credentials", "true")

		// 处理预检请求
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}

		c.Next()
	})

	// 管理员认证路由（无需认证）
	auth := r.Group("/api/v1/admin/auth")
	{
		auth.POST("/login", controller.NewAdminAuthController().Login)
	}

	// 管理员API路由组（需要认证）
	admin := r.Group("/api/v1/admin")
	admin.Use(middleware.AdminAuthMiddleware())
	{
		// 仪表盘统计
		admin.GET("/dashboard/stats", controller.NewAdminDashboardController().GetDashboardStats)

		// 图书管理
		books := admin.Group("/books")
		{
			books.GET("/list", controller.NewAdminBookController().GetBookList)
			books.GET("/:id", controller.NewAdminBookController().GetBookByID)
			books.POST("/create", controller.NewAdminBookController().CreateBook)
			books.PUT("/:id", controller.NewAdminBookController().UpdateBook)
			books.DELETE("/:id", controller.NewAdminBookController().DeleteBook)
			books.PUT("/:id/status", controller.NewAdminBookController().UpdateBookStatus)
		}

		// 分类管理
		categories := admin.Group("/categories")
		{
			categories.GET("/list", controller.NewAdminBookController().GetCategories)
			categories.POST("/create", controller.NewAdminBookController().CreateCategory)
			categories.PUT("/:id", controller.NewAdminBookController().UpdateCategory)
			categories.DELETE("/:id", controller.NewAdminBookController().DeleteCategory)
		}

		// 用户管理
		users := admin.Group("/users")
		{
			users.GET("/list", controller.NewAdminUserController().GetUserList)
			users.GET("/:id", controller.NewAdminUserController().GetUserByID)
			users.POST("/create", controller.NewAdminUserController().CreateUser)
			users.PUT("/:id", controller.NewAdminUserController().UpdateUser)
			users.DELETE("/:id", controller.NewAdminUserController().DeleteUser)
			users.PUT("/:id/status", controller.NewAdminUserController().UpdateUserStatus)
		}
	}

	return r
}
