package router

import (
	"bookstore/global"
	"bookstore/repository"
	"bookstore/service"
	"bookstore/web/controller"
	"bookstore/web/mw"

	"github.com/gin-gonic/gin"
)

func InitRouter() *gin.Engine {
	r := gin.Default()

	// 添加CORS中间件
	r.Use(func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Origin, Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization")
		c.Header("Access-Control-Expose-Headers", "Content-Length")
		c.Header("Access-Control-Allow-Credentials", "true")

		// 处理预检请求
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}

		c.Next()
	})

	// 创建DAO实例
	favoriteDAO := repository.NewFavoriteDAO()
	carouselDAO := repository.NewCarouselDAO(global.DBClient)

	// 创建Service实例
	favoriteService := service.NewFavoriteService(favoriteDAO)
	carouselService := service.NewCarouselService(carouselDAO)

	// 创建控制器实例
	userController := controller.NewUserController()
	captchaController := controller.NewCaptchaController()
	bookController := controller.NewBookController()
	categoryController := controller.NewCategoryController()
	orderController := controller.NewOrderController()
	favoriteController := controller.NewFavoriteController(favoriteService)
	carouselController := controller.NewCarouselController(carouselService)

	// API v1 路由组
	v1 := r.Group("/api/v1")
	{
		// 用户相关路由
		user := v1.Group("/user")
		{
			// 无需认证的路由
			user.POST("/register", userController.Register)
			user.POST("/login", userController.Login)

			// 需要认证的路由
			auth := user.Group("")
			auth.Use(mw.JWTAuthMiddleware())
			{
				auth.GET("/profile", userController.GetUserProfile)
				auth.PUT("/profile", userController.UpdateUserProfile)
				auth.PUT("/password", userController.ChangePassword)
				auth.DELETE("/logout", userController.Logout)
			}
		}

		// 书籍相关路由
		book := v1.Group("/book")
		{
			book.GET("/list", bookController.GetBookList)
			book.GET("/detail/:id", bookController.GetBookDetail)
			book.GET("/search", bookController.SearchBooks)
			book.GET("/category/:category", bookController.GetBooksByCategory)
			book.GET("/hot", bookController.GetHotBooks)
			book.GET("/new", bookController.GetNewBooks)
		}

		// 分类相关路由
		category := v1.Group("/category")
		{
			category.GET("/list", categoryController.GetCategories)
			category.GET("/:id", categoryController.GetCategoryByID)
			category.POST("/create", categoryController.CreateCategory)
			category.PUT("/:id", categoryController.UpdateCategory)
			category.DELETE("/:id", categoryController.DeleteCategory)
		}

		// 订单相关路由
		order := v1.Group("/order")
		order.Use(mw.JWTAuthMiddleware())
		{
			order.POST("/create", orderController.CreateOrder)
			order.GET("/:id", orderController.GetOrderByID)
			order.GET("/list", orderController.GetUserOrders)
			order.POST("/:id/pay", orderController.PayOrder)
			order.GET("/statistics", orderController.GetOrderStatistics)
		}

		// 收藏相关路由
		favorite := v1.Group("/favorite")
		favorite.Use(mw.JWTAuthMiddleware())
		{
			favorite.POST("/:id", favoriteController.AddFavorite)
			favorite.DELETE("/:id", favoriteController.RemoveFavorite)
			favorite.GET("/:id/check", favoriteController.CheckFavorite)
			favorite.GET("/list", favoriteController.GetUserFavorites)
			favorite.GET("/count", favoriteController.GetUserFavoriteCount)
		}

		// 验证码相关路由
		captcha := v1.Group("/captcha")
		{
			captcha.GET("/generate", captchaController.GenerateCaptcha)
			captcha.POST("/verify", captchaController.VerifyCaptcha)
		}

		// 轮播图相关路由
		carousel := v1.Group("/carousel")
		{
			carousel.GET("/list", carouselController.GetActiveCarousels)
			carousel.GET("/:id", carouselController.GetCarouselByID)
			carousel.POST("/create", carouselController.CreateCarousel)
			carousel.PUT("/:id", carouselController.UpdateCarousel)
			carousel.DELETE("/:id", carouselController.DeleteCarousel)
		}
	}

	return r
}
